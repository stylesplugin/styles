<?php

// Setup the env
date_default_timezone_set('GMT');
$system = '/Users/anthonyshort/Dropbox/Projects/Scaffold/Core/';
include $system.'/lib/Scaffold/Environment.php';
Scaffold_Environment::auto_load(true);

// Configuration
$config = array(
	'extensions' => array(
		'Variables',
		'XMLVariables'
	)
);

// Create Scaffold instance
$container 	= new Scaffold_Container($system,$config);
$scaffold 	= $container->build();

// Load in the CSS file
$source = new Scaffold_Source_File('vars.css');

// Rather than parsing the whole thing through Scaffold, we just want the
// variables that are inside that source. So to save some time, we just get them manually.
$ext = $scaffold->extensions['Variables'];

// Pull out the variables into an array 
$variables = $ext->extract($source);

// Have a look!
print_r($variables);

// Now to save them back as an XML file
$scaffold->extensions['XMLVariables']->save($variables,'vars.xml');

// Now when you load this XML file into the CSS, they will override the
// default values in the @variable blocks. You can build a UI
// just from declaring CSS @variable block within a theme file 